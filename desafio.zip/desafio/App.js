import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  Image
} from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Qual é o pais acima?',
    opcoes: ['Mexico', 'Costa do marfim', 'Irlanda', 'Italia'],
    respostaCerta: 1,
   imagem: 'https://flagsapi.com/CI/flat/64.png'},

  {
    id: 2,
    pergunta: 'Qual é o pais acima?',
    opcoes: ['Suecia', 'Canada', 'Noruega', 'Suiça'],
    respostaCerta: 2,
    imagem:'https://flagsapi.com/NO/flat/64.png'
  },

  {
    id: 3,
    pergunta: 'Qual é o pais acima?',
    opcoes: ['Portugal', 'Inglaterra', 'Brasil', 'Mexico'],
    respostaCerta: 0,
    imagem:'https://flagsapi.com/PT/flat/64.png'
  },

 {

  id: 4,
  pergunta: 'Qual é o país acima?',
  opcoes: ['Noruega', 'Suécia', 'Finlândia', 'Dinamarca'],
  respostaCerta: 1,
  imagem:'https://flagsapi.com/SE/flat/64.png'
},


{
  id: 5,
  pergunta: 'Qual é o país acima?',
  opcoes: ['Brasil', 'Argentina', 'Portugal', 'México'],
  respostaCerta: 0,
  imagem:'https://flagsapi.com/BR/flat/64.png'
},

{
  id: 6,
  pergunta: 'Qual é o país acima?',
  opcoes: ['Japão', 'China', 'Coreia do Sul', 'Tailândia'],
  respostaCerta: 0,
  imagem:'https://flagsapi.com/JP/flat/64.png'
},

{
  id: 7,
  pergunta: 'Qual é o país acima?',
  opcoes: ['Canadá', 'Estados Unidos', 'Inglaterra', 'Austrália'],
  respostaCerta: 0,
  imagem:'https://flagsapi.com/CA/flat/64.png'
},

{
  id: 8,
  pergunta: 'Qual é o país acima?',
  opcoes: ['Alemanha', 'Bélgica', 'França', 'Holanda'],
  respostaCerta: 0,
  imagem:'https://flagsapi.com/DE/flat/64.png'
},

{
  id: 9,
  pergunta: 'Qual é o país acima?',
  opcoes: ['Itália', 'França', 'Irlanda', 'México'],
  respostaCerta: 0,
  imagem:'https://flagsapi.com/IT/flat/64.png'
},

{
  id: 10,
  pergunta: 'Quem Vencera a copa do mundo?',
  opcoes: ['Brasil', 'Franca', 'Argentina', 'Espanha'],
  respostaCerta: 0,
  imagem:'https://www.visa.com.br/content/dam/VCOM/regional/lac/brazil/newsroom/visa-traz-trofeu-do-campeao-da-copa-do-mundo-da-FIFA-800x450.jpg'
},
]

export default function AppQuiz() {

  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const [respostaSelecionada, setRespostaSelecionada] = useState(null);
  const [bloqueado, setBloqueado] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setTelaAtual('quiz');
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {

    setRespostaSelecionada(indiceClicado);

    // trava os botões
    setBloqueado(true);

    // mostra a cor por 1 segundo
    setTimeout(() => {

      setCarregando(true);

      setTimeout(() => {

        const pergunta = QUIZ[perguntaAtual];

        if (indiceClicado === pergunta.respostaCerta) {
          setPontuacao((prev) => prev + 1);
        }

        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(perguntaAtual + 1);
        } else {
          setTelaAtual('resultado');
        }

        setCarregando(false);
        setRespostaSelecionada(null);
        setBloqueado(false);

      }, 1500);

    }, 1000);
  }

  // ==========================================
  // TELA INICIAL
  // ==========================================

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>

        <Image
          source={{ uri: 'https://cdn.jornaldaparaiba.com.br/img/inline/210000/Copa-do-Mundo-2026-conheca-a-Trionda-bola-oficial-0021348700202510040824.webp?xid=1170998' }}
          style={styles.logoInicial}
        />

        <Text style={styles.tituloPrincipal}>Quiz da Copa</Text>

        <Text style={styles.subtituloInicio}>
          Vamos mergulhar no clima de copa do mundo?
        </Text>

        <TouchableOpacity
          style={styles.botaoIniciar}
          onPress={iniciarJogo}
          activeOpacity={0.8}
        >
          <Text style={styles.textoBotaoIniciar}>
            INICIAR JOGO
          </Text>
        </TouchableOpacity>

      </View>
    );
  }

  // ==========================================
  // TELA RESULTADO
  // ==========================================

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>

        <Text style={styles.titulo}>
          Fim de Jogo!
        </Text>

        <Text style={styles.subtitulo}>
          Você acertou {pontuacao} de {QUIZ.length} perguntas.
        </Text>

        <TouchableOpacity
          style={styles.botaoAcao}
          onPress={voltarAoInicio}
          activeOpacity={0.8}
        >
          <Text style={styles.textoBotaoAcao}>
            Voltar ao Início
          </Text>
        </TouchableOpacity>

      </View>
    );
  }

  // ==========================================
  // LOADING
  // ==========================================

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>

        <ActivityIndicator
          size="large"
          color="#3b82f6"
        />

        <Text style={styles.textoCarregando}>
          Validando resposta...
        </Text>

      </View>
    );
  }

  // ==========================================
  // QUIZ
  // ==========================================

  const pergunta = QUIZ[perguntaAtual];

  return (
    <View style={styles.tela}>

      <View style={styles.cabecalho}>

        <Text style={styles.progresso}>
          Pergunta {perguntaAtual + 1} de {QUIZ.length}
        </Text>

        <Text style={styles.pontos}>
          Pontos: {pontuacao}
        </Text>

      </View>

      <View style={styles.cartaoPergunta}>

        <Image
          source={{ uri: pergunta.imagem }}
          style={styles.imagemPergunta}
        />

        <Text style={styles.textoPergunta}>
          {pergunta.pergunta}
        </Text>

      </View>

      <View style={styles.areaOpcoes}>

        {pergunta.opcoes.map((opcao, index) => (

          <TouchableOpacity
            key={index}

            style={[
              styles.botaoOpcao,

              respostaSelecionada === index &&
              index === pergunta.respostaCerta && {
                backgroundColor: '#22c55e',
                borderColor: '#22c55e'
              },

              respostaSelecionada === index &&
              index !== pergunta.respostaCerta && {
                backgroundColor: '#ef4444',
                borderColor: '#ef4444'
              }
            ]}

            onPress={() => responder(index)}

            activeOpacity={0.7}

            disabled={bloqueado}
          >

            <Text style={styles.textoOpcao}>
              {opcao}
            </Text>

          </TouchableOpacity>

        ))}

      </View>

    </View>
  );
}

// ==========================================
// ESTILOS
// ==========================================

const styles = StyleSheet.create({

  tela: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 20,
    paddingTop: 60
  },

  telaCentrada: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20
  },

logoInicial: {
  width: 125,
  height: 125,
  borderRadius: 50,
  marginBottom: 10
},

  tituloPrincipal: {
    fontSize: 36,
    fontWeight: '900',
    color: '#1e293b',
    marginBottom: 10,
    textAlign: 'center'
  },

  subtituloInicio: {
    fontSize: 16,
    color: 'black',
    marginBottom: 50,
    textAlign: 'center',
    paddingHorizontal: 20
  },

  botaoIniciar: {
    backgroundColor: '#6d28d9',
    paddingVertical: 20,
    paddingHorizontal: 40,
    borderRadius: 20,
    width: '100%',
    maxWidth: 300,
    alignItems: 'center'
  },

  textoBotaoIniciar: {
    color: 'white',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: 1
  },

  cabecalho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
    paddingHorizontal: 10
  },

  progresso: {
    fontSize: 16,
    fontWeight: '700',
    color: '#64748b'
  },

  pontos: {
    fontSize: 16,
    fontWeight: '800',
    color: '#22c55e'
  },

  cartaoPergunta: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 20,
    marginBottom: 30,
    elevation: 5
  },

imagemPergunta: {
  width: '100%',
  height: 220,
  borderRadius: 20,
  marginBottom: 20,
  resizeMode: 'cover',
},

  textoPergunta: {
    fontSize: 22,
    fontWeight: '800',
    color: '#1e293b',
    textAlign: 'center',
    lineHeight: 30
  },

  areaOpcoes: {
    flex: 1
  },

  botaoOpcao: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 15,
    marginBottom: 15,
    borderWidth: 2,
    borderColor: '#e2e8f0'
  },

  textoOpcao: {
    fontSize: 18,
    color: '#334155',
    fontWeight: '600',
    textAlign: 'center'
  },

  titulo: {
    fontSize: 32,
    fontWeight: '900',
    color: '#0f172a',
    marginBottom: 10
  },

  subtitulo: {
    fontSize: 18,
    color: '#64748b',
    marginBottom: 40,
    textAlign: 'center'
  },

  botaoAcao: {
    backgroundColor: '#3b82f6',
    paddingVertical: 18,
    paddingHorizontal: 40,
    borderRadius: 16,
    width: '100%',
    maxWidth: 300,
    alignItems: 'center'
  },

  textoBotaoAcao: {
    color: 'white',
    fontSize: 18,
    fontWeight: '800'
  },

  textoCarregando: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: '600',
    color: '#3b82f6'
  }

});