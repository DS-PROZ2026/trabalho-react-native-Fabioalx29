import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Keyboard, Pressable  } from 'react-native';

import { LinearGradient } from 'expo-linear-gradient';


export default function App() {
  const [displayValue, setDisplayValue] = useState('');
  const [num1, setNum1] = useState(null);
  const [operation, setOperation] = useState(null);

  const onPressNumber = (num) => {
    setDisplayValue((prev) => prev + num);
  };

  const onPressBackspace = () => {
    setDisplayValue((prev) => prev.slice(0, -1));
  };

  const onPressClear = () => {
    setDisplayValue('');
    setNum1(null);
    setOperation(null);
  };

  const selectOperation = (op) => {
    if (displayValue === '') return;
    setNum1(parseFloat(displayValue));
    setOperation(op);
    setDisplayValue('');
  };

  const calculateResult = () => {
    if (!operation || displayValue === '' || num1 === null) return;

    const num2 = parseFloat(displayValue);
    let result = 0;

    switch (operation) {
      case '+':
        result = num1 + num2;
        break;
      case '-':
        result = num1 - num2;
        break;
      case '*':
        result = num1 * num2;
        break;
      case '/': 
        if (num2 === 0) {
          alert('Não é possível dividir por zero!');
          onPressClear();
          return;
        }
        result = num1 / num2;
        break;
      case '%':
        result = (num1 * num2) / 100;
        break;
      default:
        return;
    }

    const formattedResult = Number.isInteger(result) ? result.toString() : result.toFixed(4).replace(/\.?0+$/, '');
    setDisplayValue(formattedResult);
    setNum1(null);
    setOperation(null);
  };

  return (
    <View style={styles.container}>
      
  

     
      <View style={styles.visorContainer}>
        <Text style={styles.visorTexto} numberOfLines={1} adjustsFontSizeToFit>
          {displayValue || '0'}
        </Text>
      </View>

      <View style={styles.keyboardContainer}>
        <View style={styles.numericBlock}>
          <View style={styles.row}>
            {['1', '2', '3'].map((n) => (
              <Pressable key={n} style={styles.button} onPress={() => onPressNumber(n)}>
                <Text style={styles.buttonText}>{n}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.row}>
            {['4', '5', '6'].map((n) => (
              <Pressable key={n} style={styles.button} onPress={() => onPressNumber(n)}>
                <Text style={styles.buttonText}>{n}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.row}>
            {['7', '8', '9'].map((n) => (
              <Pressable key={n} style={styles.button} onPress={() => onPressNumber(n)}>
                <Text style={styles.buttonText}>{n}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.row}>
            <Pressable style={[styles.button, styles.actionButton]} onPress={onPressClear}>
              <Text style={styles.actionText}>C</Text>
            </Pressable>
            <Pressable style={styles.button} onPress={() => onPressNumber('0')}>
              <Text style={styles.buttonText}>0</Text>
            </Pressable>
            <Pressable style={[styles.button, styles.actionButton]} onPress={onPressBackspace}>
              <Text style={styles.actionText}>⌫</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.operationBlock}>
          <Pressable onPress={() => selectOperation('%')}>
            <LinearGradient colors={['#4ade80', 'yellow']} style={styles.opButtonGradient}>
              <Text style={styles.opButtonText}>%</Text>
            </LinearGradient>
          </Pressable>

          <Pressable onPress={() => selectOperation('/')}>
            <LinearGradient colors={['#4ade80', 'yellow']} style={styles.opButtonGradient}>
              <Text style={styles.opButtonText}>÷</Text>
            </LinearGradient>
          </Pressable>

          <Pressable onPress={() => selectOperation('*')}>
            <LinearGradient colors={['yellow', '#4ade80']} style={styles.opButtonGradient}>
              <Text style={styles.opButtonText}>×</Text>
            </LinearGradient>
          </Pressable>

          <Pressable onPress={() => selectOperation('+')}>
            <LinearGradient colors={['#4ade80', 'yellow']} style={styles.opButtonGradient}>
              <Text style={styles.opButtonText}>+</Text>
            </LinearGradient>
          </Pressable>

          <Pressable onPress={() => selectOperation('-')}>
            <LinearGradient colors={['#4ade80', 'yellow']} style={styles.opButtonGradient}>
              <Text style={styles.opButtonText}>-</Text>
            </LinearGradient>
          </Pressable>

         
          <Pressable onPress={calculateResult}>
            <LinearGradient colors={['#3b82f6', '#1d4ed8']} style={styles.equalsButtonGradient}>
              <Text style={styles.opButtonText}>=</Text>
            </LinearGradient>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    justifyContent: 'space-between',
    paddingBottom: 30,
    paddingTop: 60,
  },
    tituloMaskContainer: {
    height: 40,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  titulo: {
    fontSize: 28,
    fontWeight: '800',
    textAlign: 'center',
    backgroundColor: 'transparent',
  },
  visorContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingHorizontal: 30,
    paddingVertical: 20,
  },
  visorTexto: {
    fontSize: 54,
    fontWeight: 'bold',
    textAlign: 'right',
    color: '#0F172A',
  },
  keyboardContainer: {
    flexDirection: 'row',
    paddingHorizontal: 10,
  },
  numericBlock: {
    flex: 3,
    justifyContent: 'space-between',
  },
  operationBlock: {
    flex: 1,
    justifyContent: 'space-between',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 12,
  },
  button: {
    width: '28%',
    aspectRatio: 1.1,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
  },
  actionButton: {
    backgroundColor: '#E4E9F2',
  },
  opButtonGradient: {
    width: '85%',
    aspectRatio: 1.1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    alignSelf: 'center',
    marginBottom: 8,
  },
  equalsButtonGradient: {
    width: '85%',
    aspectRatio: 1.1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    alignSelf: 'center',
  },
  buttonText: {
    fontSize: 26,
    fontWeight: '600',
    color: '#1E293B',
  },
  actionText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#64748B',
  },
  opButtonText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
});